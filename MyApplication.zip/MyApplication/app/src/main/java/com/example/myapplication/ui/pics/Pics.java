package com.example.myapplication.ui.pics;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Pics extends ViewModel {

    private MutableLiveData<String> mText;

    public Pics() {
        mText = new MutableLiveData<>();
        mText.setValue("Cycling Images");
    }

    public LiveData<String> getText() {
        return mText;
    }
}